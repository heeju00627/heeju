"""
===========================================================
Hierarchical clustering: structured vs unstructured ward
===========================================================

Example builds a swiss roll dataset and runs
hierarchical clustering on their position.

For more information, see :ref:`hierarchical_clustering`.

In a first step, the hierarchical clustering is performed without connectivity
constraints on the structure and is solely based on distance, whereas in
a second step the clustering is restricted to the k-Nearest Neighbors
graph: it's a hierarchical clustering with structure prior.

Some of the clusters learned without connectivity constraints do not
respect the structure of the swiss roll and extend across different folds of
the manifolds. On the opposite, when opposing connectivity constraints,
the clusters form a nice parcellation of the swiss roll.
"""

# Authors : Vincent Michel, 2010
#           Alexandre Gramfort, 2010
#           Gael Varoquaux, 2010
# License: BSD 3 clause

print(__doc__)

import time as time
import numpy as np
import matplotlib.pyplot as plt
import mpl_toolkits.mplot3d.axes3d as p3
from mpl_toolkits.mplot3d import Axes3D
from sklearn.cluster import AgglomerativeClustering
from sklearn.datasets.samples_generator import make_swiss_roll
from collections import Counter

from PyQt5 import QtCore, QtGui, QtWidgets
from PyQt5.QtWidgets import QFileDialog
from PyQt5.QtWidgets import QApplication, QMainWindow, QMenu, QVBoxLayout, QSizePolicy, QMessageBox, QWidget, QPushButton
from PyQt5.QtGui import QIcon

from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.figure import Figure
import matplotlib.pyplot as plt

###############################################################################
# Generate data (swiss roll dataset)
n_samples = 1500
noise = 0.05

def load_input(input_file):
    data = []
    with open(input_file, "r") as f:
        while (True):
            line = f.readline().strip()
            if not line: break

            splited = line.strip().split(" ")
            if len(splited) == 3:
                x = float(splited[0])
                y = float(splited[1])
                z = float(splited[2])
                data.append([x,y,z])
            else:
                print (line)
                print ("Exceptional case")
    return data



np.random.seed(5)

centers = [[1, 1], [-1, -1], [1, -1]]
#iris = datasets.load_new()
#X = iris.data
#y = iris.target
w = []
y = []
z = []
clas = []
names = []
data = []
X = []
with open('bm.txt', 'r') as bm:
            
    n=bm.readline()
    print(n)
    for i in range(int(n)):
        line=bm.readline().split('\t')
        w.append(int(line[0]))
        y.append(int(line[1]))
        clas.append(int(line[2]))
            
        #print("AAA")
        #print(len(x))
with open('umx.txt', 'r') as umx:
    matrix = umx.read().split("\n")
            
    for i in range(int(n)):
        tmp=matrix[w[i]]
        s=tmp.split('\t')
        z.append(float(s[y[i]]))
        #print(len(clas))
        #print(len(x))
        #print(len(y))
        #print(len(z))
for i in range(int(n)):
            #data.append([x[i], y[i], z[i], clas[i]])
    X.append([w[i], y[i], z[i]])


#X=load_input('train.txt')
X = np.array(X)
c = np.array(clas)
#X, _ = make_swiss_roll(n_samples, noise)
print(X)
# Make it thinner
X[:, 1] *= .5

###############################################################################
"""# Compute clustering
print("Compute unstructured hierarchical clustering...")
st = time.time()
ward = AgglomerativeClustering(n_clusters=6, linkage='ward').fit(X)
elapsed_time = time.time() - st
label = ward.labels_
print("Elapsed time: %.2fs" % elapsed_time)
print("Number of points: %i" % label.size)

###############################################################################
# Plot result
fig = plt.figure()
ax = p3.Axes3D(fig)
ax.view_init(7, -80)
for l in np.unique(label):
    ax.plot3D(X[label == l, 0], X[label == l, 1], X[label == l, 2],
              'o', color=plt.cm.jet(np.float(l) / np.max(label + 1)))
plt.title('Without connectivity constraints (time %.2fs)' % elapsed_time)"""


###############################################################################
# Define the structure A of the data. Here a 10 nearest neighbors
from sklearn.neighbors import kneighbors_graph
connectivity = kneighbors_graph(X, n_neighbors=10, include_self=False)

###############################################################################
# Compute clustering
print("Compute structured hierarchical clustering...")
st = time.time()
ward = AgglomerativeClustering(n_clusters=5, connectivity=connectivity,
                               linkage='ward').fit(X)
elapsed_time = time.time() - st
label = ward.labels_

match = []
class0 = []
class1 = []
class2 = []
class3 = []
class4 = []
        
for i in range(int(n)):
    match.append([label[i], c[i]])
            #print(match)
    if (label[i] == 0):
        class0.append(c[i])
    elif (label[i] == 1):
        class1.append(c[i])
    elif (label[i] == 2):
        class2.append(c[i])
    elif (label[i] == 3):
        class3.append(c[i])
    elif (label[i] == 4):
        class4.append(c[i])
            
    cnt0=Counter(class0)
    cnt1=Counter(class1)
    cnt2=Counter(class2)
    cnt3=Counter(class3)
    cnt4=Counter(class4)

print("\n\nPrecision")
        #print(clas.count(0))
print("0: ",cnt0[0]/(cnt0[0]+cnt0[1]+cnt0[2]+cnt0[3]+cnt0[4]))
        #print(clas.count(1))
print("1: ",cnt1[1]/(cnt1[0]+cnt1[1]+cnt1[2]+cnt1[3]+cnt1[4]))
        #print(clas.count(2))
print("2: ",cnt2[2]/(cnt2[0]+cnt2[1]+cnt2[2]+cnt2[3]+cnt2[4]))
        #print(clas.count(3))
print("3: ",cnt3[3]/(cnt3[0]+cnt3[1]+cnt3[2]+cnt3[3]+cnt3[4]))
        #print(clas.count(4))
print("4: ",cnt4[4]/(cnt4[0]+cnt4[1]+cnt4[2]+cnt4[3]+cnt4[4]))


print("\n\nRecall")
        #print(clas.count(0))
print("0: ",cnt0[0]/(cnt0[0]+cnt1[0]+cnt2[0]+cnt3[0]+cnt4[0]))
        #print(clas.count(1))
print("1: ",cnt1[1]/(cnt0[1]+cnt1[1]+cnt2[1]+cnt3[1]+cnt4[1]))
        #print(clas.count(2))
print("2: ",cnt2[2]/(cnt0[2]+cnt1[2]+cnt2[2]+cnt3[2]+cnt4[2]))
        #print(clas.count(3))
print("3: ",cnt3[3]/(cnt0[3]+cnt1[3]+cnt2[3]+cnt3[3]+cnt4[3]))
        #print(clas.count(4))
print("4: ",cnt4[4]/(cnt0[4]+cnt1[4]+cnt2[4]+cnt3[4]+cnt4[4]))


#print("Elapsed time: %.2fs" % elapsed_time)
#print("Number of points: %i" % label.size)

###############################################################################
# Plot result
fig = plt.figure()
ax = p3.Axes3D(fig, rect=[0, 0, .95, 1], elev=48, azim=134)
ax.view_init(30, -30)
for l in np.unique(label):
    ax.plot3D(X[label == l, 0], X[label == l, 1], X[label == l, 2],
              'o', color=plt.cm.jet(float(l) / np.max(label + 1)))
#ax.scatter(X[:, 0], X[:, 1], X[:, 2], c=labels.astype(np.float))

#plt.title('With connectivity constraints (time %.2fs)' % elapsed_time)

plt.show()

